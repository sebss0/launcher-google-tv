# WaveRush — fix del destello azul al tocar

Este paquete parte del HTML original del juego. La corrección se centra en el resaltado azul de toque del navegador Android WebView: el HTML original no definía `-webkit-tap-highlight-color`.

## Cambio realizado
Se aplica globalmente `-webkit-tap-highlight-color: transparent !important` a todos los elementos y pseudo-elementos, además de desactivar selección y menú táctil en la superficie del juego.

**No se ha cambiado la secuencia de temas ni la jugabilidad.**

## Crear APK con GitHub
1. Sube todo el contenido de este ZIP a la raíz de un repositorio.
2. Abre GitHub Actions y ejecuta **Build WaveRush APK**.
3. Descarga el artefacto `WaveRush-Android-APK`.

El workflow genera un APK debug para probar. La compilación y la prueba física aún deben ejecutarse.
