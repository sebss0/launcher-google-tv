# Wave Rush — Android (GitHub Actions)

Este proyecto empaqueta el juego HTML original como aplicación Android mediante Capacitor.

## Crear el APK en GitHub

1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido** de este ZIP (no el ZIP como único archivo).
3. Abre la pestaña **Actions** del repositorio.
4. Si GitHub solicita habilitar Actions, acepta.
5. Ejecuta **Compilar APK de Wave Rush** con `Run workflow`, o haz un `push` a `main`/`master`.
6. Cuando termine el flujo, abre la ejecución y descarga el artefacto **wave-rush-apk**.
7. Dentro del ZIP del artefacto encontrarás `app-debug.apk`, listo para instalar en un dispositivo Android.

## Desarrollo local

Requiere Node.js 22, Java 21 y Android SDK.

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK generado en `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notas

- Identificador Android: `com.waverush.game`.
- Nombre de la aplicación: `Wave Rush`.
- La compilación de GitHub genera un APK **debug**. No es una APK firmada para publicar en Google Play.
- El juego conserva su HTML/CSS/JavaScript y usa almacenamiento local del WebView para los récords.
- Se corrigió el reinicio del modo clásico: el código original se llamaba a sí mismo indefinidamente al reintentar.
