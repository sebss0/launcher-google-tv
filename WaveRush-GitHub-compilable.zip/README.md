# WaveRush — proyecto compilable para GitHub

Este paquete contiene el juego web extraído del APK original y el ajuste para evitar el destello azul de selección/toque de Android WebView.

## Compilar APK con GitHub Actions

1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido** de este ZIP a la raíz del repositorio.
3. Abre la pestaña **Actions**.
4. Ejecuta **Build WaveRush APK** (o haz un push a la rama `main`).
5. Cuando termine, descarga el artefacto **WaveRush-Android-APK**. Dentro estará `app-debug.apk`.

## Compilar localmente

Requisitos: Node.js 20, Java 17 y Android SDK.

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK resultante: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Nota

- El proyecto conserva el identificador Android `com.waverush.game` y el nombre `Wave Rush`.
- Este workflow genera un APK **debug** instalable para pruebas. Para publicar o distribuir una versión firmada de producción, hay que configurar una clave de firma propia y compilar `assembleRelease`.
- El APK anterior que fallaba al instalar no debe reutilizarse.
